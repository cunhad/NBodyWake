function y = isongpu(x)
    y = isa(x,'gpuArray');
end